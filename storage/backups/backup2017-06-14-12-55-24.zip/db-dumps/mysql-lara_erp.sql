
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `abastecimentos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abastecimentos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `frotas_id` int(11) DEFAULT NULL,
  `data` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `combustivel` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `documento` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lts` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `preco_lts` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contas_id` int(11) DEFAULT NULL,
  `km_anterior` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `km_atual` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `km_rodado` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `km_lts` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `abastecido_em` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `abastecido_por` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `estado` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `abastecimentos` WRITE;
/*!40000 ALTER TABLE `abastecimentos` DISABLE KEYS */;
/*!40000 ALTER TABLE `abastecimentos` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `armazenagens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `armazenagens` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `produtos_id` int(11) NOT NULL,
  `filiais_id` int(11) NOT NULL,
  `local` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `armazenagens` WRITE;
/*!40000 ALTER TABLE `armazenagens` DISABLE KEYS */;
INSERT INTO `armazenagens` VALUES (34,5,1,'asdasdasd',NULL,NULL),(35,7,1,'A1Z2',NULL,NULL);
/*!40000 ALTER TABLE `armazenagens` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `atendimentos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `atendimentos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `contatos_id` int(11) NOT NULL,
  `assunto` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `texto` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `atendimentos` WRITE;
/*!40000 ALTER TABLE `atendimentos` DISABLE KEYS */;
/*!40000 ALTER TABLE `atendimentos` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `attachments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `attachments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `contatos_id` int(11) DEFAULT NULL,
  `attachmentable_id` int(11) NOT NULL,
  `attachmentable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `path` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `attachments` WRITE;
/*!40000 ALTER TABLE `attachments` DISABLE KEYS */;
INSERT INTO `attachments` VALUES (1,1,1,'App\\contatos','public/CI1GdMkyOLd5Kj5KezGKsUFZD5dNeDFevWZZQy3W.jpeg','Cartão 2',NULL,'2017-05-23 21:40:43','2017-05-24 00:58:51'),(2,1,1,'App\\Contas','public/9ywtUNvHZH4USFMZXJ4ECNfQqKohYCfiP9t1jWw3.jpeg','Mudei de novo','2017-05-31 20:15:06','2017-05-24 00:58:08','2017-05-31 20:15:06'),(3,1,1,'App\\Contas','public/vM0WGqCOtGs0tVtSzXgFjUVD542DOBb9dzBG0Yry.jpeg','vM0WGqCOtGs0tVtSzXgFjUVD542DOBb9dzBG0Yry.jpeg','2017-05-31 20:28:56','2017-05-31 20:19:25','2017-05-31 20:28:56'),(4,1,1,'App\\Contas','public/xGRvNvL65txKpUAR8sPlak5IjYfSytVJZyd81w6S.jpeg','xGRvNvL65txKpUAR8sPlak5IjYfSytVJZyd81w6S.jpeg','2017-05-31 20:31:04','2017-05-31 20:29:15','2017-05-31 20:31:04'),(5,1,1,'App\\Contas','public/WeXlx7HbPaCUncbONuTdGlgH4HSUux7rCfzapcH2.jpeg','WeXlx7HbPaCUncbONuTdGlgH4HSUux7rCfzapcH2.jpeg','2017-05-31 20:31:05','2017-05-31 20:29:23','2017-05-31 20:31:05'),(6,1,1,'App\\Contas','public/vAOhhE2H6jMFuPNjANfa0nas5lOjKBhY2EQM9Uxg.jpeg','vAOhhE2H6jMFuPNjANfa0nas5lOjKBhY2EQM9Uxg.jpeg','2017-05-31 20:31:05','2017-05-31 20:29:56','2017-05-31 20:31:05'),(7,1,1,'App\\Contas','public/zWTFbNBxtFqSb94n6WhDOBEEgJAK9GorVtVdp3e5.jpeg','zWTFbNBxtFqSb94n6WhDOBEEgJAK9GorVtVdp3e5.jpeg','2017-05-31 20:31:06','2017-05-31 20:31:00','2017-05-31 20:31:06'),(8,1,1,'App\\Contas','public/eqNHYrZmA7CrF4Sq9dCh2FNvC6zh3OEzfgH0x4fm.jpeg','eqNHYrZmA7CrF4Sq9dCh2FNvC6zh3OEzfgH0x4fm.jpeg',NULL,'2017-06-01 00:32:28','2017-06-01 00:32:28'),(9,18,2,'App\\Contas','public/2Bw2PvfXOxLXFB2LuPVjCWMdR0JDvJGPFoRDHm2t.png','2Bw2PvfXOxLXFB2LuPVjCWMdR0JDvJGPFoRDHm2t.png',NULL,'2017-06-02 21:08:13','2017-06-02 21:08:13');
/*!40000 ALTER TABLE `attachments` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `bancos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bancos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `filial_id` int(11) NOT NULL,
  `contatos_id` int(11) DEFAULT NULL,
  `agencia` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cc` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cc_dig` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `comp` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `valor` double NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `bancos` WRITE;
/*!40000 ALTER TABLE `bancos` DISABLE KEYS */;
INSERT INTO `bancos` VALUES (1,1,33,'11111111-1','CC','22222222','4','3333-3',9900,'2017-06-05 17:03:14','2017-06-05 22:19:59',NULL),(2,1,33,'11111111-1','CC','22222222','4','3333-3',1,'2017-06-05 17:04:17','2017-06-05 18:42:21','2017-06-05 18:42:21'),(3,1,33,'11111111-1','CC','22222222','4','3333-3',1000,'2017-06-05 17:05:27','2017-06-05 18:42:23','2017-06-05 18:42:23'),(4,1,38,'11111111-1','CC','22222222','3','4444-4',5555432,'2017-06-06 02:23:48','2017-06-06 02:40:56',NULL);
/*!40000 ALTER TABLE `bancos` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `caixas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `caixas` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `filial_id` int(11) NOT NULL,
  `funcionario_id` int(11) NOT NULL,
  `estado` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contatos_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `caixas` WRITE;
/*!40000 ALTER TABLE `caixas` DISABLE KEYS */;
/*!40000 ALTER TABLE `caixas` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `cats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cats` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `contatos_id` int(11) NOT NULL,
  `hora` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `percurso` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `codigo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `estado` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `obs` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `inicio` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `final` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `cats` WRITE;
/*!40000 ALTER TABLE `cats` DISABLE KEYS */;
/*!40000 ALTER TABLE `cats` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `combobox_texts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `combobox_texts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `combobox_textable_id` int(11) NOT NULL,
  `combobox_textable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `field` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `text` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `combobox_texts` WRITE;
/*!40000 ALTER TABLE `combobox_texts` DISABLE KEYS */;
INSERT INTO `combobox_texts` VALUES (1,1,'App\\Telefones','(XX) X XXXX-XXXX','Numero','Cel Corp',NULL,NULL,NULL),(2,1,'App\\Telefones','(XX) X XXXX-XXXX','Numero','Cel Part',NULL,NULL,NULL),(3,1,'App\\Telefones','(XX) X XXXX-XXXX','Numero','Cel Rec',NULL,NULL,NULL),(4,1,'App\\Telefones','(XX) XXXX-XXXX','Numero','Tel Part',NULL,NULL,NULL),(5,1,'App\\Telefones','(XX) XXXX-XXXX','Numero','Tel Corp',NULL,NULL,NULL),(6,1,'App\\Telefones','(XX) XXXX-XXXX','Numero','Tel Rec',NULL,NULL,NULL),(7,1,'App\\Telefones','','E-Mail','E-Mail Corp',NULL,NULL,NULL),(8,1,'App\\Telefones','','E-Mail','E-Mail Part',NULL,NULL,NULL),(9,1,'App\\Contas\\Formas','tipo','Dinheiro','Dinheiro',NULL,NULL,NULL),(10,1,'App\\Contas\\Formas','tipo','Pagamento online','Pagamento online',NULL,NULL,NULL),(11,1,'App\\Contas\\Formas','tipo','Cartão de Credito','Cartão de Credito',NULL,NULL,NULL),(12,1,'App\\Contas\\Formas','tipo','Cartão de Debito','Cartão de Debito',NULL,NULL,NULL),(13,1,'App\\Contas\\Formas','tipo','Transferencia mesmo banco','Transferencia mesmo banco',NULL,NULL,NULL),(14,1,'App\\Contas\\Formas','tipo','Ted','Ted',NULL,NULL,NULL),(15,1,'App\\Contas\\Formas','tipo','Doc','Doc',NULL,NULL,NULL),(16,1,'App\\Consumos','tipo','1001','Conta de Agua',NULL,NULL,NULL),(17,1,'App\\Consumos','tipo','1002','Conta de Energia Eletrica',NULL,NULL,NULL),(18,1,'App\\Consumos','tipo','1003','Internet e Telefone',NULL,NULL,NULL),(19,1,'App\\Consumos','tipo','1004','Gas encanado',NULL,NULL,NULL),(20,1,'App\\Contas','tipo','Prestação de serviços','Prestação de serviços',NULL,NULL,NULL),(21,1,'App\\Contas','tipo','Material de Escritorio','Material de Escritorio',NULL,NULL,NULL),(22,1,'App\\Contas','tipo','Diversos','Diversos',NULL,NULL,NULL),(23,1,'App\\Relacionamento','tipo','Cliente','Fornecedor',NULL,NULL,NULL),(24,1,'App\\Relacionamento','tipo','Fornecedor','Cliente',NULL,NULL,NULL),(25,1,'App\\Relacionamento','tipo','Matriz','Filial',NULL,NULL,NULL),(26,1,'App\\Relacionamento','tipo','Empresa','Funcionario',NULL,NULL,NULL),(27,1,'App\\Relacionamento','tipo','Funcionario','Empresa',NULL,NULL,NULL);
/*!40000 ALTER TABLE `combobox_texts` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `contas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contas` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `contatos_id` int(11) DEFAULT NULL,
  `referente` int(11) DEFAULT NULL,
  `usuarios_id` int(11) DEFAULT NULL,
  `bancos_id` int(11) DEFAULT NULL,
  `estado` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tipo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nome` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `descricao` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `valor` double(8,2) DEFAULT NULL,
  `vencimento` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pagamento` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `desconto` double DEFAULT NULL,
  `dm` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `contas` WRITE;
/*!40000 ALTER TABLE `contas` DISABLE KEYS */;
INSERT INTO `contas` VALUES (1,1,1,1,1,'0','11','aaa',NULL,1.00,'11/11/2017','3',4,'5',NULL,'2017-06-05 22:33:46','2017-06-05 22:33:46'),(2,18,2,1,4,'1','0','Prestação de serviços',NULL,123.00,'0',NULL,0,'1','2017-06-01 15:07:10','2017-06-06 02:40:56',NULL),(3,19,3,1,1,'1','0','Prestação de serviços','<p>123123123</p>',100.00,'05/06/2017',NULL,0,'4','2017-06-02 21:05:43','2017-06-05 22:20:00',NULL);
/*!40000 ALTER TABLE `contas` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `contas_consumos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contas_consumos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `contas_id` int(11) NOT NULL,
  `codigo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mes` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `consumo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cat` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `valor_anterior` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `valor_atual` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sub_item1` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sub_item2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `contas_consumos` WRITE;
/*!40000 ALTER TABLE `contas_consumos` DISABLE KEYS */;
/*!40000 ALTER TABLE `contas_consumos` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `contatos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contatos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `codigo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tipo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nome` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sobrenome` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nascimento` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cpf` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rg` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cod_prefeitura` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sociabilidade` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `active` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `obs` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `contatos` WRITE;
/*!40000 ALTER TABLE `contatos` DISABLE KEYS */;
INSERT INTO `contatos` VALUES (1,NULL,'0','WEBGS',NULL,NULL,'123123123123',NULL,NULL,'1','4','<p>Aeeeeeeeeeeeeeeeeeeeee</p>','2017-05-23 17:07:51','2017-05-23 21:52:47',NULL),(2,NULL,'0','WebGS M.E.','Web.GS.',NULL,'12345678901234',NULL,NULL,'2','4',NULL,'2017-05-23 17:09:08','2017-05-23 17:11:27','2017-05-23 17:11:27'),(3,NULL,'1','PESSOA','FISICA',NULL,'1',NULL,NULL,'5','4',NULL,'2017-05-23 17:17:37','2017-05-23 20:29:51','2017-05-23 20:29:51'),(4,NULL,'1','ABC','DEFG','6','123','4',NULL,'4','4',NULL,'2017-05-23 17:19:56','2017-05-23 20:30:13','2017-05-23 20:30:13'),(5,NULL,'1','teste','123',NULL,'111111111111',NULL,NULL,'3','4',NULL,'2017-05-23 20:13:29','2017-05-23 20:29:54','2017-05-23 20:29:54'),(6,NULL,'1','teste','123',NULL,'111111111112',NULL,NULL,'3','4',NULL,'2017-05-23 20:15:47','2017-05-23 20:29:57','2017-05-23 20:29:57'),(7,NULL,'1','teste','123',NULL,'111111111113',NULL,NULL,'3','4',NULL,'2017-05-23 20:18:43','2017-05-23 20:29:59','2017-05-23 20:29:59'),(8,NULL,'0','aaa','aaa',NULL,'2',NULL,NULL,'3','4',NULL,'2017-05-23 20:25:15','2017-05-23 20:30:04','2017-05-23 20:30:04'),(9,NULL,'0','aaa','aaa',NULL,'3',NULL,NULL,'3','4',NULL,'2017-05-23 20:25:46','2017-05-23 20:30:08','2017-05-23 20:30:08'),(10,NULL,'0','aaa','aaa',NULL,'4',NULL,NULL,'3','4',NULL,'2017-05-23 20:26:03','2017-05-23 20:30:10','2017-05-23 20:30:10'),(11,NULL,'0','aaa','aaa',NULL,'5',NULL,NULL,'3','4',NULL,'2017-05-23 20:26:53','2017-05-23 20:30:11','2017-05-23 20:30:11'),(12,NULL,'0','bbb','bbb',NULL,'22',NULL,NULL,'3','4',NULL,'2017-05-23 20:27:21','2017-05-23 20:30:15','2017-05-23 20:30:15'),(13,NULL,'0','bbb','bbb',NULL,'222',NULL,NULL,'3','4',NULL,'2017-05-23 20:28:32','2017-05-23 20:30:16','2017-05-23 20:30:16'),(14,NULL,'0','bbb','bbb',NULL,'2222',NULL,NULL,'4','4',NULL,'2017-05-23 20:29:30','2017-05-24 15:04:48','2017-05-24 15:04:48'),(15,NULL,'1','Aaaaaa','bbbbbbb',NULL,'123123123',NULL,NULL,'3','4',NULL,'2017-05-23 21:05:55','2017-05-24 15:04:50','2017-05-24 15:04:50'),(16,NULL,'0','xxxxxx','xxxxxxxx',NULL,'33333333333333',NULL,NULL,'3','4',NULL,'2017-05-23 21:09:54','2017-05-24 15:04:53','2017-05-24 15:04:53'),(17,NULL,'0','xxxxxx','xxxxxxxx',NULL,'33333333333334',NULL,NULL,'3','4',NULL,'2017-05-23 21:11:51','2017-05-24 15:04:55','2017-05-24 15:04:55'),(18,NULL,'0','Carlos Castro ME','Notebook Center e Cia',NULL,'9239238300019','445445445988',NULL,'4','4','<p>Loja de manutenção de notebook, PCs e tablets</p>','2017-05-24 15:04:42','2017-05-24 19:06:12',NULL),(19,NULL,'1','Artur','Sena e Silva','210592','38552947803','42',NULL,'5','4',NULL,'2017-05-24 19:09:42','2017-05-24 19:09:42',NULL),(20,NULL,'2','Teste','123',NULL,'12312312312',NULL,NULL,'3','4',NULL,'2017-05-29 16:03:10','2017-05-29 16:11:24','2017-05-29 16:11:24'),(21,NULL,'2','Teste','123',NULL,'44444444444',NULL,NULL,'3','4',NULL,'2017-05-29 16:05:05','2017-05-29 16:11:26','2017-05-29 16:11:26'),(22,NULL,'2','Teste','123',NULL,'44444444445',NULL,NULL,'3','4',NULL,'2017-05-29 16:06:00','2017-05-29 16:11:28','2017-05-29 16:11:28'),(23,NULL,'2','aaaa','wwwwww',NULL,'55555555555',NULL,NULL,'3','4',NULL,'2017-05-29 16:08:52','2017-05-29 16:11:21','2017-05-29 16:11:21'),(24,NULL,'2','aaaa','wwwwww',NULL,'55555555556',NULL,NULL,'3','4',NULL,'2017-05-29 16:09:19','2017-05-29 16:11:22','2017-05-29 16:11:22'),(25,NULL,'2','Teste','123123123',NULL,NULL,NULL,NULL,'3','4',NULL,'2017-05-29 16:11:40','2017-05-29 17:05:42','2017-05-29 17:05:42'),(26,NULL,'2','Teste','123123123',NULL,'77777777777',NULL,NULL,'3','4',NULL,'2017-05-29 16:13:22','2017-05-29 17:05:51','2017-05-29 17:05:51'),(27,NULL,'2','Teste','123',NULL,'22222222222',NULL,NULL,'3','4',NULL,'2017-05-29 16:14:16','2017-05-29 17:05:53','2017-05-29 17:05:53'),(28,NULL,'2','Teste','123',NULL,'22222222233',NULL,NULL,'3','4',NULL,'2017-05-29 16:15:04','2017-05-29 17:05:55','2017-05-29 17:05:55'),(29,NULL,'2','Teste','123',NULL,'22222222234',NULL,NULL,'3','4',NULL,'2017-05-29 16:15:56','2017-05-29 17:05:57','2017-05-29 17:05:57'),(30,NULL,'2','Teste','123',NULL,'22222222231',NULL,NULL,'3','4',NULL,'2017-05-29 16:16:19','2017-05-29 17:05:59','2017-05-29 17:05:59'),(31,NULL,'2','Teste','123',NULL,'22222222230',NULL,NULL,'3','4',NULL,'2017-05-29 16:16:46','2017-05-29 17:06:11','2017-05-29 17:06:11'),(32,NULL,'2','Teste','123',NULL,'22222222238',NULL,NULL,'3','4',NULL,'2017-05-29 16:17:03','2017-05-29 17:06:14','2017-05-29 17:06:14'),(33,NULL,'2','Teste','123',NULL,'22222222212',NULL,NULL,'3','4',NULL,'2017-05-29 16:18:55','2017-05-29 16:18:55',NULL),(34,NULL,'0','Olá!','Td bem?',NULL,'11.111.111',NULL,NULL,'3','4',NULL,'2017-06-05 23:25:34','2017-06-05 23:25:34',NULL),(35,NULL,'0','aaaaaaaaaaa','ccccccc',NULL,'33.333.33',NULL,NULL,'3','4',NULL,'2017-06-05 23:29:16','2017-06-05 23:29:16',NULL),(36,NULL,'0','1231','123123',NULL,'21.312.3',NULL,NULL,'3','4',NULL,'2017-06-05 23:29:48','2017-06-05 23:29:48',NULL),(37,NULL,'0','1231','123123',NULL,'21.312.312/3123',NULL,NULL,'3','4',NULL,'2017-06-05 23:30:10','2017-06-05 23:30:10',NULL),(38,NULL,'0','ROBERTO','ROBERTO',NULL,'88.888.888',NULL,NULL,'3','4',NULL,'2017-06-06 00:58:41','2017-06-06 00:58:41',NULL),(39,NULL,'0','123123','123123123',NULL,'12.312.312',NULL,NULL,'3','4',NULL,'2017-06-06 00:59:38','2017-06-06 00:59:38',NULL),(40,NULL,'0','ddddd','ddddd',NULL,'87.867.867/8678',NULL,NULL,'3','4',NULL,'2017-06-06 01:00:50','2017-06-06 01:00:50',NULL),(41,NULL,'0','ertwerwer','werwer',NULL,'45.645.654/6',NULL,NULL,'3','4',NULL,'2017-06-06 01:02:36','2017-06-06 01:02:36',NULL);
/*!40000 ALTER TABLE `contatos` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `contatos_pivot`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contatos_pivot` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `from_id` int(11) NOT NULL,
  `from_text` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `to_id` int(11) NOT NULL,
  `to_text` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `contatos_pivot` WRITE;
/*!40000 ALTER TABLE `contatos_pivot` DISABLE KEYS */;
INSERT INTO `contatos_pivot` VALUES (1,21,'Funcionario',1,'Trabalho',NULL,NULL),(2,22,'Funcionario',1,'Trabalho',NULL,NULL),(3,23,'Funcionario',1,'Trabalho',NULL,NULL),(4,24,'Funcionario',1,'Trabalho',NULL,NULL),(5,25,'Funcionario',1,'Trabalho',NULL,NULL),(6,26,'Funcionario',1,'Trabalho',NULL,NULL),(7,27,'Funcionario',1,'Trabalho',NULL,NULL),(8,28,'Funcionario',1,'Trabalho',NULL,NULL),(9,29,'Funcionario',1,'Trabalho',NULL,NULL),(10,30,'Funcionario',1,'Trabalho',NULL,NULL),(11,31,'Funcionario',1,'Trabalho',NULL,NULL),(12,32,'Funcionario',1,'Trabalho',NULL,NULL),(26,33,'Funcionario',1,'Trabalho',NULL,NULL);
/*!40000 ALTER TABLE `contatos_pivot` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `discriminacoes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `discriminacoes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `contas_id` int(11) DEFAULT NULL,
  `nome` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `valor` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `discriminacoes` WRITE;
/*!40000 ALTER TABLE `discriminacoes` DISABLE KEYS */;
/*!40000 ALTER TABLE `discriminacoes` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `enderecos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `enderecos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `contatos_id` int(11) DEFAULT NULL,
  `tipo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cep` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `endereco` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `numero` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `complemento` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bairro` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cidade` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `uf` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `obs` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `enderecos` WRITE;
/*!40000 ALTER TABLE `enderecos` DISABLE KEYS */;
INSERT INTO `enderecos` VALUES (1,1,'Entrega','19780000','Rua a','1','Compl','B','C','SP','aaaaaaaa',NULL,'2017-05-23 21:39:10','2017-05-23 21:39:10'),(2,17,'Correspondencia','13500140','Rua 1',NULL,NULL,'Centro','Rio Claro','sp',NULL,'2017-05-23 21:11:51','2017-05-23 21:38:28','2017-05-23 21:38:28'),(3,18,'Comercial','14801290','Rua Gonçalves Dias','678',NULL,'Centro','Araraquara','sp',NULL,'2017-05-24 15:07:35','2017-05-24 15:07:35',NULL),(4,19,'Residencia','14811588','Rua Dr. Alonso de Martinez','65',NULL,'Altos de Pinheiros 2','Araraquara','SP',NULL,'2017-05-24 19:09:42','2017-05-24 19:09:42',NULL);
/*!40000 ALTER TABLE `enderecos` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `erp_configs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `erp_configs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `field` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `text` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `options` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `erp_configs` WRITE;
/*!40000 ALTER TABLE `erp_configs` DISABLE KEYS */;
INSERT INTO `erp_configs` VALUES (1,'field_codigo','Campo \'Codigo\'','0','',NULL,NULL,NULL),(2,'img_destaque','Imagem de destaque','Cartão 2','1',NULL,NULL,'2017-06-13 21:05:07'),(3,'modulo_atendimentos','Modulo \"Atendimentos\"','1','',NULL,NULL,NULL),(4,'modulo_contas','Modulo \"Contas\"','1','',NULL,'2017-06-13 16:09:54','2017-06-13 16:09:54'),(5,'modulo_bancos','Modulo \"Bancos\"','1','',NULL,'2017-06-13 16:09:54','2017-06-13 16:09:54'),(6,'modulo_tickets','MODULO \"Tickets\"','1','',NULL,'2017-06-13 16:09:54','2017-06-13 16:09:54'),(7,'modulo_caixas','Modulo \"Caixas\"','1','',NULL,'2017-06-13 16:09:54','2017-06-13 16:09:54'),(8,'modulo_vendas','Modulo \"Vendas\"','1','',NULL,'2017-06-13 16:09:54','2017-06-13 16:09:54'),(9,'modulo_estoques','Modulo \"Estoques\"','1','',NULL,'2017-06-13 16:09:54','2017-06-13 16:09:54'),(10,'modulo_frotas','Modulo \"Frotas\"','1','',NULL,'2017-06-13 16:09:54','2017-06-13 16:09:54');
/*!40000 ALTER TABLE `erp_configs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `est_movimentacoes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `est_movimentacoes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `estoque_id` int(11) NOT NULL,
  `vendas_id` int(11) NOT NULL,
  `quantidade` double NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `est_movimentacoes` WRITE;
/*!40000 ALTER TABLE `est_movimentacoes` DISABLE KEYS */;
/*!40000 ALTER TABLE `est_movimentacoes` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `estoque`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `estoque` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `contatos_id` int(11) NOT NULL,
  `produtos_id` int(11) DEFAULT NULL,
  `quantidade` double(8,2) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `estoque` WRITE;
/*!40000 ALTER TABLE `estoque` DISABLE KEYS */;
INSERT INTO `estoque` VALUES (1,1,1,2.00,'2017-06-12 20:52:04','2017-06-12 20:52:04',NULL),(2,1,2,2.00,'2017-06-12 20:53:06','2017-06-12 20:53:06',NULL),(3,1,3,2.00,'2017-06-12 20:57:58','2017-06-12 20:57:58',NULL);
/*!40000 ALTER TABLE `estoque` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `estoque_campos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `estoque_campos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `estoque_id` int(11) NOT NULL,
  `tipo` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nome` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `valor` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `estoque_campos` WRITE;
/*!40000 ALTER TABLE `estoque_campos` DISABLE KEYS */;
INSERT INTO `estoque_campos` VALUES (1,5,'0','Teste','teste','2017-06-08 18:22:38','2017-06-08 18:25:48','2017-06-08 18:25:48'),(2,5,'0','a','b','2017-06-08 18:26:40','2017-06-08 18:26:54','2017-06-08 18:26:54');
/*!40000 ALTER TABLE `estoque_campos` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `frotas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `frotas` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `contatos_id` int(11) DEFAULT NULL,
  `placa` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `marca` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modelo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ano` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cor` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `combustivel` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `renavan` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `chassis` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `compra` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `estado` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `frotas` WRITE;
/*!40000 ALTER TABLE `frotas` DISABLE KEYS */;
/*!40000 ALTER TABLE `frotas` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `funcionarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `funcionarios` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `contatos_id` int(11) NOT NULL,
  `cargo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `estado` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_adm` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_dem` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cnh` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cnh_cat` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cnh_venc` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cart_trab_num` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cart_trab_serie` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `eleitor` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `eleitor_sessao` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `eleitor_zona` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `eleitor_exp` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pis` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pis_banco` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `inss` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rg_exp` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rg_pai` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rg_mae` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ajuda_custo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reservista` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sal` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sal_real` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sal_inss` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vt` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vt_percentual` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `va` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vr` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `peri` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `peri_percentual` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `com_fixo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `com_perc` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `funcionarios` WRITE;
/*!40000 ALTER TABLE `funcionarios` DISABLE KEYS */;
INSERT INTO `funcionarios` VALUES (1,29,'Tester',NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,'0',NULL,'0',NULL,'0',NULL,'0',NULL,NULL,NULL,NULL,'2017-05-29 16:15:57','2017-05-29 16:15:57'),(2,30,'Tester',NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,'0',NULL,'0',NULL,'0',NULL,'0',NULL,NULL,NULL,NULL,'2017-05-29 16:16:19','2017-05-29 16:16:19'),(3,31,'Tester',NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,'0',NULL,'0',NULL,'0',NULL,'0',NULL,NULL,NULL,NULL,'2017-05-29 16:16:46','2017-05-29 16:16:46'),(4,32,'Tester',NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,'0',NULL,'0',NULL,'0',NULL,'0',NULL,NULL,NULL,NULL,'2017-05-29 16:17:03','2017-05-29 16:17:03'),(5,33,'Tester',NULL,'111111','111111','5',NULL,'7','1',NULL,NULL,NULL,NULL,NULL,'3','4','10',NULL,NULL,NULL,NULL,NULL,'100','1,000','1','100','10',NULL,'2','110','11',NULL,NULL,NULL,NULL,'2017-05-29 16:18:55','2017-05-29 19:17:58');
/*!40000 ALTER TABLE `funcionarios` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=97 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (65,'2014_10_12_000000_create_users_table',1),(66,'2014_10_12_100000_create_password_resets_table',1),(67,'2016_11_06_163403_create_contatos_table',1),(68,'2016_11_17_123248_create_telefones_table',1),(69,'2016_11_24_215712_create_contatos_pivot_table2',1),(70,'2016_11_29_171816_create_atendimento_table',1),(71,'2016_12_01_162001_create_contas_table',1),(72,'2016_12_09_183304_create_estoque_table',1),(73,'2016_12_22_131122_create_attachments_table',1),(74,'2016_12_22_231333_create_caixas_table',1),(75,'2016_12_26_205859_create_vendas_table',1),(76,'2016_12_26_205932_create_est_movimentacoes_table',1),(77,'2017_01_05_151209_create_movs_table',1),(78,'2017_01_06_112212_create_combobox_textable_table',1),(79,'2017_01_11_225906_create_discriminacoes_table',1),(80,'2017_01_18_125211_create_funcionarios_table',1),(81,'2017_01_19_142844_create_cats_table',1),(82,'2017_01_20_170011_create_erp_configs_table',1),(83,'2017_01_23_225530_create_contas_consumo_table',1),(84,'2017_02_09_121635_create_frotas_table',1),(85,'2017_02_11_132640_create_abastecimentos_table',1),(86,'2017_02_20_222832_create_estoque_campos_table',1),(87,'2017_02_23_154835_create_bancos_table',1),(88,'2017_02_24_091032_create_produtos_table',1),(89,'2017_02_25_170921_create_enderecos_table',1),(90,'2017_03_12_134659_create_produtos_grupos',1),(91,'2017_03_12_134735_create_produtos_tipos',1),(92,'2017_03_16_151606_create_produtos_semelhantes_table',1),(93,'2017_03_17_092403_create_armazenagens_table',1),(94,'2017_03_17_111653_create_semelhantes_externos_table',1),(95,'2017_03_20_140150_create_nf_entradas_table',1),(96,'2017_03_20_140735_create_nf_produtos',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `movs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `movs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `caixas_id` int(11) DEFAULT NULL,
  `valor` double DEFAULT NULL,
  `tipo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `estado` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nome` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `obs` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `movs` WRITE;
/*!40000 ALTER TABLE `movs` DISABLE KEYS */;
/*!40000 ALTER TABLE `movs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `nf_entradas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nf_entradas` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `filiais_id` int(11) NOT NULL,
  `fornecedor_id` int(11) NOT NULL,
  `estado` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `numero` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `frete` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `transportadora` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `seguro` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `icms` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `icms_substituicao` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `acrescimo` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `desconto` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `obs` text COLLATE utf8mb4_unicode_ci,
  `criado_por` int(11) NOT NULL,
  `atualizado_por` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `nf_entradas` WRITE;
/*!40000 ALTER TABLE `nf_entradas` DISABLE KEYS */;
INSERT INTO `nf_entradas` VALUES (1,1,19,NULL,'1','110','0','0','0','0',NULL,'0','0',NULL,1,NULL,'2017-06-12 20:51:01','2017-06-12 20:51:01',NULL),(2,1,19,NULL,'1','110','0','0','0','0',NULL,'0','0',NULL,1,NULL,'2017-06-12 20:52:04','2017-06-12 20:52:04',NULL),(3,1,19,NULL,'1','3','0','0','0','0',NULL,'0','0',NULL,1,NULL,'2017-06-12 20:53:06','2017-06-12 20:53:06',NULL),(4,1,19,NULL,'1','109','0','0','0','0',NULL,'0','0',NULL,1,NULL,'2017-06-12 20:57:58','2017-06-12 20:57:58',NULL);
/*!40000 ALTER TABLE `nf_entradas` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `nf_produtos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nf_produtos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `notas_id` int(11) NOT NULL,
  `produtos_id` int(11) NOT NULL,
  `ncm` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantidade` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `valor` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `icms` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ipi` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_icms` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_ipi` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `nf_produtos` WRITE;
/*!40000 ALTER TABLE `nf_produtos` DISABLE KEYS */;
INSERT INTO `nf_produtos` VALUES (1,1,7,'1','2','50','5','5','100','5','5','Conjunto','2017-06-12 20:52:04','2017-06-12 20:52:04'),(2,1,7,'1','2','50','3','3','100','3','3','Conjunto','2017-06-12 20:53:06','2017-06-12 20:53:06'),(3,1,7,'2','2','50','5','5','100','5','5','Fardo','2017-06-12 20:57:58','2017-06-12 20:57:58');
/*!40000 ALTER TABLE `nf_produtos` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `produtos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `produtos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `campos_id` int(11) DEFAULT NULL,
  `nome` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `barras` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tipo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `grupo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `unidade` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `descricao` text COLLATE utf8mb4_unicode_ci,
  `produtos_tipo_id` int(11) DEFAULT NULL,
  `fabricante_id` int(11) DEFAULT NULL,
  `margem` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `venda` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `qtd_minima` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `qtd_maxima` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `embalagem` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `estado` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `aplicacao` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `peso` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `produtos` WRITE;
/*!40000 ALTER TABLE `produtos` DISABLE KEYS */;
INSERT INTO `produtos` VALUES (1,NULL,'1111111','99171297',NULL,NULL,NULL,NULL,NULL,NULL,19,NULL,NULL,'1','2',NULL,NULL,NULL,NULL,'2017-06-08 15:02:02','2017-06-08 15:19:07','2017-06-08 15:19:07'),(2,NULL,'1111111','99057001',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-06-08 15:04:07','2017-06-08 16:36:25','2017-06-08 16:36:25'),(3,NULL,'Teste 1','39507867',NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-06-08 16:38:17','2017-06-08 16:50:18','2017-06-08 16:50:18'),(4,NULL,'Teste 2','18157235',NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-06-08 16:49:36','2017-06-08 16:50:20','2017-06-08 16:50:20'),(5,NULL,'Teste 3','94063973',NULL,NULL,NULL,NULL,NULL,1,36,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-06-08 16:50:09','2017-06-08 21:31:58','2017-06-08 21:31:58'),(6,NULL,'NOVO','11727008',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-06-08 20:12:12','2017-06-08 21:32:00','2017-06-08 21:32:00'),(7,NULL,'Mais teste','39414421',NULL,NULL,NULL,NULL,NULL,1,41,NULL,NULL,NULL,NULL,NULL,NULL,'Usamos isto',NULL,'2017-06-08 21:51:50','2017-06-08 22:21:15',NULL);
/*!40000 ALTER TABLE `produtos` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `produtos_grupos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `produtos_grupos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nome` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `produtos_grupos` WRITE;
/*!40000 ALTER TABLE `produtos_grupos` DISABLE KEYS */;
INSERT INTO `produtos_grupos` VALUES (1,'Teste 2','2017-06-07 16:37:03','2017-06-07 17:24:36',NULL);
/*!40000 ALTER TABLE `produtos_grupos` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `produtos_semelhantes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `produtos_semelhantes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `produtos_id_1` int(11) NOT NULL,
  `produtos_id_2` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `produtos_semelhantes` WRITE;
/*!40000 ALTER TABLE `produtos_semelhantes` DISABLE KEYS */;
INSERT INTO `produtos_semelhantes` VALUES (8,5,6,NULL,NULL,NULL);
/*!40000 ALTER TABLE `produtos_semelhantes` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `produtos_tipos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `produtos_tipos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `produtos_grupos_id` int(11) NOT NULL,
  `nome` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `produtos_tipos` WRITE;
/*!40000 ALTER TABLE `produtos_tipos` DISABLE KEYS */;
INSERT INTO `produtos_tipos` VALUES (1,1,'Sub teste 2','2017-06-07 21:28:56','2017-06-07 22:11:01',NULL),(2,1,'Sub 2','2017-06-07 21:31:07','2017-06-07 21:31:07',NULL);
/*!40000 ALTER TABLE `produtos_tipos` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `semelhantes_externos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `semelhantes_externos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `produtos_id` int(11) NOT NULL,
  `codigo` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nome` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `origem` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `semelhantes_externos` WRITE;
/*!40000 ALTER TABLE `semelhantes_externos` DISABLE KEYS */;
/*!40000 ALTER TABLE `semelhantes_externos` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `telefones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `telefones` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `contatos_id` int(11) NOT NULL,
  `tipo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `numero` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contato` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `setor` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ramal` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `telefones` WRITE;
/*!40000 ALTER TABLE `telefones` DISABLE KEYS */;
INSERT INTO `telefones` VALUES (1,1,'E-Mail Corp','aa@aa.com','C','S','R',NULL,NULL),(2,1,NULL,NULL,NULL,NULL,NULL,'2017-05-23 20:18:43','2017-05-23 20:18:43'),(3,18,'Tel Corp','1633570458','Loja',NULL,NULL,'2017-05-24 19:06:13','2017-05-24 19:06:13'),(4,18,'Tel Corp','1633570459','Loja 2',NULL,NULL,'2017-05-24 19:06:13','2017-05-24 19:06:13'),(5,19,'Cel Corp','16996160622','Artur',NULL,NULL,'2017-05-24 19:09:42','2017-05-24 19:09:42');
/*!40000 ALTER TABLE `telefones` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `contatos_id` int(11) NOT NULL,
  `trabalho_id` int(11) NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ativo` int(11) NOT NULL,
  `perms` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,1,1,'empresa','$2y$10$jJQFC7YoG9XBhHdCBuQDkevZLqGAG4tWkmPx1derDmmLgI7VxRs9e','0mcz89dyBasNtk0dMyzl5fgeAHv3S8iU0cfcS7GT68WTjK7T7bVwkuv98nyn',1,'{\"admin\":\"1\",\"contatos\":{\"leitura\":\"1\", \"edicao\":\"1\", \"adicao\":\"1\"},\"bancos\":{\"leitura\":\"1\", \"edicao\":\"1\", \"adicao\":\"1\"},\"atendimentos\":{\"leitura\":\"1\", \"edicao\":\"1\", \"adicao\":\"1\"},\"tickets\":{\"leitura\":\"1\", \"edicao\":\"1\", \"adicao\":\"1\"},\"contas\":{\"leitura\":\"1\", \"edicao\":\"1\", \"adicao\":\"1\"},\"caixas\":{\"leitura\":\"1\", \"edicao\":\"1\", \"adicao\":\"1\"},\"vendas\":{\"leitura\":\"1\", \"edicao\":\"1\", \"adicao\":\"1\"},\"estoques\":{\"leitura\":\"1\", \"edicao\":\"1\", \"adicao\":\"1\"},\"frotas\":{\"leitura\":\"1\", \"edicao\":\"1\", \"adicao\":\"1\"}}',NULL,NULL),(2,33,1,'artur','$2y$10$qs96hQLHpYEjQFDC/jLO2eeAR9tAkoOzt1ta4RsVXNvWDMaNWJFly',NULL,1,'\"{\\\"contatos\\\":{\\\"leitura\\\":\\\"1\\\",\\\"adicao\\\":\\\"1\\\",\\\"edicao\\\":\\\"0\\\"}\"','2017-05-29 16:18:55','2017-05-29 19:17:58');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `vendas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vendas` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `funcionario_id` int(11) NOT NULL,
  `comprador_id` int(11) DEFAULT NULL,
  `valor` double NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `vendas` WRITE;
/*!40000 ALTER TABLE `vendas` DISABLE KEYS */;
/*!40000 ALTER TABLE `vendas` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

