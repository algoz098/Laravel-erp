<?php $__env->startSection('content'); ?>
  <div class="row">
    <div class="col-md-4">
      <div class="panel panel-default">
        <div class="panel-heading"><i class="fa fa-users fa-1x"></i> Total de contatos/fornecedores</div>
        <div class="panel-body text-center">
         <span style="font-size:2em;"><?php echo count($contatos); ?></span>
        </div>
      </div>
    </div>
    <div class="col-md-4">
      <div class="panel panel-default">
        <div class="panel-heading"><i class="fa fa-wrench fa-1x"></i> Caixa de opções</div>
        <div class="panel-body">
          <a href="<?php echo e(url('/contatos/novo')); ?>"><span style="font-size:1.5em;"><i class="fa fa-plus fa-1x"></i> Novo</span></a>
        </div>
      </div>
    </div>
  </div>
  <div class="row">
    <div class="col-md-12">
      <div class="panel panel-default">
        <div class="panel-heading ">
          <i class="fa fa-users fa-1x"></i> Lista de contatos e fornecedores
        </div>
        <div class="panel-body">
          <div class="row">
            <div class="col-md-12  ">
              <form method="POST" action="<?php echo e(url('/contatos')); ?>/">
                <div class="form-group form-inline text-center">
                  <?php echo e(csrf_field()); ?>

                  <input type="text" class="form-control" name="busca" id="busca" placeholder="Busca">
                  <button type="submit" class="btn btn-success">Buscar</button>
                </div>
              </form>
            </div>
          </div>
          <?php $__currentLoopData = $contatos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $contato): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
              <div class="row list-contacts">
                <div class="col-md-3 text-center">
                  <a href="<?php echo e(url('/contatos')); ?>/<?php echo e($contato->id); ?>" class="btn btn-primary btn_xs" data-toggle="tooltip" title="Editar">
                    <i class="fa fa-wrench" ></i>
                  </a>
                  <a href="<?php echo e(url('/contatos')); ?>/<?php echo e($contato->id); ?>" class="btn btn-primary btn_xs" data-toggle="tooltip" title="Detalhes">
                    <i class="fa fa-file-text"></i>
                  </a>
                  <a href="<?php echo e(url('/contatos')); ?>/<?php echo e($contato->id); ?>/phone" class="btn btn-primary btn_xs" title="Adicionar Telefone"  data-toggle="modal" data-target="#addTelefones">
                    <i class="fa fa-phone"></i>
                  </a>
                  <a href="<?php echo e(url('/contatos')); ?>/<?php echo e($contato->id); ?>/relacoes" class="btn btn-primary btn_xs" title="Relacionamentos">
                    <i class="fa fa-users"></i>
                  </a>
                  <?php echo e($contato->id); ?>

                </div>
                <div class="col-md-2">
                  <i class="fa fa-user level<?php echo e($contato->active); ?>"></i>
                  <i class="fa fa-signal level<?php echo e($contato->sociabilidade); ?>"></i>
                  <?php echo e($contato->nome); ?> <?php echo e($contato->sobrenome); ?>

                </div>
                <div class="col-md-7">
                  <?php $__currentLoopData = $contato->telefones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $telefone): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <span class=""><span class="badge"><?php echo e($telefone->tipo); ?></span> <?php echo e($telefone->numero); ?></span>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                  <?php echo e($contato->endereco); ?> - <?php echo e($contato->bairro); ?> - <?php echo e($contato->cidade); ?> - <?php echo e($contato->uf); ?>

                </div>
              </div>
            <!-- Modal -->
            <div class="modal fade" id="addTelefones" tabindex="-1" role="dialog" aria-labelledby="addTelefonesLabel">
              <div class="modal-dialog" role="document">
                <div class="modal-content">
                  <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title" id="addTelefonesLabel">Adicionar Telefone</h4>
                  </div>
                  <div class="modal-body">
                      <?php $__currentLoopData = $contato->telefones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $telefone): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                          <a href="/erp/public/index.php/contatos/<?php echo e($contato->id); ?>/telefones/<?php echo e($telefone->id); ?>" class="btn btn-info btn-xs"><i class="fa fa-pencil"></i></a>
                          <a href="/erp/public/index.php/contatos/<?php echo e($contato->id); ?>/telefones/<?php echo e($telefone->id); ?>/delete" class="btn btn-danger btn-xs"><i class="fa fa-ban"></i></a>
                          <?php echo e(isset($telefone->tipo) ? $telefone->tipo : ""); ?> <?php echo e(isset($telefone->numero) ? $telefone->numero : ""); ?> <br>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    <a href="/erp/public/index.php/contatos/<?php echo e($contato->id); ?>/telefones"><button type="submit" class="btn btn-primary">Novo</button></a>
                  </div>
                </div>
              </div>
            </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>