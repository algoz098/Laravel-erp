<?php $__env->startSection('content'); ?>
  <div class="row">
    <div class="col-md-11">
      <form method="POST" action="/erp/public/index.php/clientes/novo/<?php echo e(isset($cliente->id) ? $cliente->id : ""); ?>">

        <div class="form-group">
        <?php echo e(csrf_field()); ?>

        <input type="hidden" name="id" value="<?php echo e(isset($cliente->id) ? $cliente->id : ""); ?>">
        <div class="panel panel-default">
          <div class="panel-heading"><i class="fa fa-users fa-1x"></i> Adicionar fornecedor/cliente</div>
          <div class="panel-body">
            <div class="row text-right">
              <div class="col-sm-offset-2 col-sm-10">
                <button type="submit" class="btn btn-success">Salvar</button>
              </div>
            </div>
            <div class="row">
              <div class="col-md-6">
                <div class="form-group">
                  <label for="text">CNPJ</label>
                  <input type="text" class="form-control" value="<?php echo e(isset($cliente->cnpj) ? $cliente->cnpj : ""); ?>" name="cnpj" id="cnpj" placeholder="CNPJ">
                </div>
              </div>
              <div class="col-md-6">
                <div class="form-group">
                  <label for="cnpj">Inscrição Estadual</label>
                  <input type="text" class="form-control" value="<?php echo e(isset($cliente->ie) ? $cliente->ie : ""); ?>" name="ie" id="ie" placeholder="I.E.">
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-12">
                <div class="form-group">
                  <label for="cnpj">Razão Social</label>
                  <input type="text" class="form-control" value="<?php echo e(isset($cliente->razao_social) ? $cliente->razao_social : ""); ?>" name="razao_social" id="razao_social" placeholder="Razão Social">
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-12">
                <div class="form-group">
                  <label for="cnpj">Nome Fantasia</label>
                  <input type="text" class="form-control" value="<?php echo e(isset($cliente->nomefantasia) ? $cliente->nomefantasia : ""); ?>" name="nome_fantasia" id="nome_fantasia" placeholder="Nome Fantasia">
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-6">
                <div class="form-group">
                  <label for="cnpj">Endereço</label>
                  <input type="text" class="form-control" value="<?php echo e(isset($cliente->endereco) ? $cliente->endereco : ""); ?>"  name="endereco" id="endereco" placeholder="Endereço">
                </div>
              </div>
              <div class="col-md-2">
                <div class="form-group">
                  <label for="cnpj">Numero</label>
                  <input type="text" class="form-control" value="<?php echo e(isset($cliente->numero) ? $cliente->numero : ""); ?>"  name="numero" id="numero" placeholder="Numero">
                </div>
              </div>
              <div class="col-md-2">
                <div class="form-group">
                  <label for="cnpj">Andar</label>
                  <input type="text" class="form-control" value="<?php echo e(isset($cliente->andar) ? $cliente->andar : ""); ?>" name="andar" id="andar" placeholder="Andar">
                </div>
              </div>
              <div class="col-md-2">
                <div class="form-group">
                  <label for="cnpj">Sala</label>
                  <input type="text" class="form-control" value="<?php echo e(isset($cliente->sala) ? $cliente->sala : ""); ?>" name="sala" id="Sala" placeholder="Sala">
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-4">
                <div class="form-group">
                  <label for="cnpj">Bairro</label>
                  <input type="text" class="form-control" value="<?php echo e(isset($cliente->bairro) ? $cliente->bairro : ""); ?>" name="bairro" id="bairro" placeholder="Bairro">
                </div>
              </div>
              <div class="col-md-2">
                <div class="form-group">
                  <label for="cnpj">CEP</label>
                  <input type="text" class="form-control" value="<?php echo e(isset($cliente->cep) ? $cliente->cep : ""); ?>" name="cep" id="cep" placeholder="CEP">
                </div>
              </div>
              <div class="col-md-4">
                <div class="form-group">
                  <label for="cnpj">Cidade</label>
                  <input type="text" class="form-control" value="<?php echo e(isset($cliente->cidade) ? $cliente->cidade : ""); ?>" name="cidade" id="cidade" placeholder="Cidade">
                </div>
              </div>
              <div class="col-md-2">
                <div class="form-group">
                  <label for="cnpj">UF</label>
                  <input type="text" class="form-control" value="<?php echo e(isset($cliente->uf) ? $cliente->uf : ""); ?>" name="uf" id="uf" placeholder="UF">
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-6">
                <div class="form-group">
                  <label for="cnpj">Contato 1</label>
                  <input type="text" class="form-control" value="<?php echo e(isset($cliente->contato1) ? $cliente->contato1 : ""); ?>" name="contato1" id="contato1" placeholder="Contato 1">
                </div>
                <div class="form-group">
                  <label for="cnpj">Departamento 1</label>
                  <input type="text" class="form-control" value="<?php echo e(isset($cliente->departamento1) ? $cliente->departamento1 : ""); ?>" name="departamento1" id="departamento1" placeholder="Departamento 1">
                </div>
                <div class="form-group">
                  <label for="cnpj">Telefone 1</label>
                  <input type="text" class="form-control" value="<?php echo e(isset($cliente->telefone1) ? $cliente->telefone1 : ""); ?>" name="telefone1" id="telefone1" placeholder="Telefone 1">
                </div>
                <div class="form-group">
                  <label for="cnpj">Ramal 1</label>
                  <input type="text" class="form-control" value="<?php echo e(isset($cliente->ramal1) ? $cliente->ramal1 : ""); ?>" name="ramal1" id="ramal1" placeholder="Ramal 1">
                </div>
                <div class="form-group">
                  <label for="cnpj">Celular 1</label>
                  <input type="text" class="form-control" value="<?php echo e(isset($cliente->celular1) ? $cliente->celular1 : ""); ?>"  name="celular1" id="celular1" placeholder="Celular 1">
                </div>
                <div class="form-group">
                  <label for="cnpj">E-Mail 1</label>
                  <input type="email" class="form-control" value="<?php echo e(isset($cliente->email1) ? $cliente->email1 : ""); ?>" name="email1" id="email1" placeholder="E-Mail 1">
                </div>
                <div class="form-group">
                  <label for="cnpj">Observação 1</label>
                  <textarea class="form-control" rows="5" value="<?php echo e(isset($cliente->obs1) ? $cliente->obs1 : ""); ?>" name="obs1" id="obs1"></textarea>
                </div>
              </div>
              <div class="col-md-6">
                <div class="form-group">
                  <label for="cnpj">Contato 2</label>
                  <input type="text" class="form-control" value="<?php echo e(isset($cliente->contato2) ? $cliente->contato2 : ""); ?>" name="contato2" id="contato2" placeholder="Contato 2">
                </div>
                <div class="form-group">
                  <label for="cnpj">Departamento 2</label>
                  <input type="text" class="form-control" value="<?php echo e(isset($cliente->departamento2) ? $cliente->departamento2 : ""); ?>" name="departamento2" id="departamento2" placeholder="Departamento 2">
                </div>
                <div class="form-group">
                  <label for="cnpj">Telefone 2</label>
                  <input type="text" class="form-control" value="<?php echo e(isset($cliente->telefone2) ? $cliente->telefone2 : ""); ?>" name="telefone2" id="telefone2" placeholder="Telefone 2">
                </div>
                <div class="form-group">
                  <label for="cnpj">Ramal 2</label>
                  <input type="text" class="form-control" value="<?php echo e(isset($cliente->ramal2) ? $cliente->ramal2 : ""); ?>" name="ramal2" id="ramal2" placeholder="Ramal 2">
                </div>
                <div class="form-group">
                  <label for="cnpj">Celular 2</label>
                  <input type="text" class="form-control" value="<?php echo e(isset($cliente->celular2) ? $cliente->celular2 : ""); ?>" name="celular2" id="celular2" placeholder="Celular 2">
                </div>
                <div class="form-group">
                  <label for="cnpj">E-Mail 2</label>
                  <input type="email" class="form-control" value="<?php echo e(isset($cliente->email2) ? $cliente->email2 : ""); ?>" name="email2" id="email2" placeholder="E-Mail 2">
                </div>
                <div class="form-group">
                  <label for="cnpj">Observação 2</label>
                  <textarea class="form-control" rows="5" value="<?php echo e(isset($cliente->obs2) ? $cliente->obs2 : ""); ?>" name="obs2" id="obs2"></textarea>
                </div>
              </div>
            </div>
            <div class="row text-right">
              <div class="form-group">
                <div class="col-sm-offset-2 col-sm-10">
                  <button type="submit" class="btn btn-success">Salvar</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </form>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>