<?php $__env->startSection('content'); ?>
  <div class="panel panel-default">
    <div class="panel-heading"><i class="fa fa-users fa-1x"></i> Controle de Usuarios</div>
    <div class="panel-body">
      <h2>Contato:</h2>
      <?php $__currentLoopData = $contatos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $contato): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
        <div class="row list-contacts h3">
          <div class="col-md-6">
            <a href="<?php echo e(url('/admin')); ?>/user/<?php echo e($contato->id); ?>" class="btn btn-info">
              <i class="fa fa-gear"></i> Acesso
            </a>
            <a href="<?php echo e(url('/admin')); ?>/access/<?php echo e($contato->id); ?>" class="btn btn-info">
              <i class="fa fa-level-up"></i> Nivel
            </a>
            <?php echo e($contato->nome); ?>


            <?php if($contato->user): ?>
              <span class="label label-<?php echo e($contato->user->ativo == 1 ? "info" : "danger"); ?>"><?php echo e($contato->user->ativo == 1 ? "Ativo" : "Inativo"); ?></span>
              <?php if(isset($contato->user->perms["admin"]) AND $contato->user->perms["admin"]==1): ?>
                <span class="label label-default">ADM</span>
              <?php endif; ?>
            <?php else: ?>
              <span class="label label-warning">Sem acesso</span>
            <?php endif; ?>

          </div>
        </div>
        <?php if($contato->user and isset($contato->user->perms["admin"])): ?>
          <!-- Modal -->
          <div class="modal fade" id="access" tabindex="-1" role="dialog" aria-labelledby="access">
            <div class="modal-dialog" role="document">
              <div class="modal-content">
                <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                  <h4 class="modal-title" id="addTelefonesLabel">Permissões de acesso</h4>
                </div>
                <div class="modal-body h3">
                    <?php $__currentLoopData = $contato->user->perms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $role): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                      <?php echo e($key); ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                  <a href="<?php echo e(url('/admin')); ?>/access/<?php echo e($contato->id); ?>"><button type="submit" class="btn btn-primary">Novo</button></a>
                </div>
              </div>
            </div>
          </div>
        <?php endif; ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>