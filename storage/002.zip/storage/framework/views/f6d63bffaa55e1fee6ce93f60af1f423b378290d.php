<?php $__env->startSection('content'); ?>
  <div class="row">
      <div class="col-md-3">
          <div class="panel panel-default text-center">
              <div class="panel-heading"><i class="fa fa-users"></i> contatos/Fornecedores:</div>
              <div class="panel-body">
                  <span style="font-size: 2em;"><?php echo count($contatos); ?></span><br>
                  <a href="<?php echo e(url('/contatos')); ?>">Ver lista</a>
              </div>
          </div>
      </div>
      <div class="col-md-3">
          <div class="panel panel-default text-center">
              <div class="panel-heading"><i class="fa fa-users"></i> Funcionarios:</div>
              <div class="panel-body">
                  <span style="font-size: 2em;"><?php echo count($funcionarios); ?></span><br>
                  <a href="<?php echo e(url('/funcionarios')); ?>">Ver lista</a>
              </div>
          </div>
      </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>