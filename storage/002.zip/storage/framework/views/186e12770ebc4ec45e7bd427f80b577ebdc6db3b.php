<?php $__env->startSection('content'); ?>
  <div class="row">
    <div class="col-md-11">
      <form method="POST" action="<?php echo e(url('/contatos')); ?>/<?php echo e($contato->id); ?>/relacoes/novo">
        <div class="form-group">
        <?php echo e(csrf_field()); ?>

        <div class="panel panel-default">
          <div class="panel-heading"><i class="fa fa-users fa-1x"></i> Editar relacionamento de <span class="label label-primary"><?php echo e($contato->nome); ?></span> com <span class="label label-primary"><?php echo e($relacao); ?></span></div>
          <?php echo e($contato->from[0]->pivot); ?>

          <div class="panel-body">
            <div class="row text-right">
              <div class="col-sm-offset-2 col-sm-10">
                <button type="submit" class="btn btn-success">Salvar</button>
              </div>
            </div>
            <div class="row form-inline">
              <div class="col-md-9" id="form">
                <div class="row">
                  <div class="form-group">
                    <label for="text"><span class="label label-primary"><?php echo e($contato->nome); ?></span> é </label>
                    <input type="text" class="form-control" value="" name="from_text" id="from_text" placeholder="Texto de relacionamento">
                    de <span id="to" class="label label-success"></span>
                  </div>
                </div>
              </div>
            </div>
        </div>
      </form>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>