<?php $__env->startSection('content'); ?>
  <div class="row">
    <div class="col-md-4">
      <div class="panel panel-default">
        <div class="panel-heading"><i class="fa fa-users fa-1x"></i> Total de clientes/fornecedores</div>
        <div class="panel-body text-center">
         <span style="font-size:2em;"><?php echo count($clientes); ?></span>
        </div>
      </div>
    </div>
    <div class="col-md-4">
      <div class="panel panel-default">
        <div class="panel-heading"><i class="fa fa-wrench fa-1x"></i> Caixa de opções</div>
        <div class="panel-body">
          <a href="<?php echo e(url('/clientes/novo')); ?>"><span style="font-size:1.5em;"><i class="fa fa-plus fa-1x"></i> Novo</span></a>
        </div>
      </div>
    </div>
  </div>
  <div class="row">
    <div class="col-md-12">
      <div class="panel panel-default">
        <div class="panel-heading"><i class="fa fa-users fa-1x"></i> Lista de clientes e fornecedores</div>
        <div class="panel-body">
          <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $cliente): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <a href="<?php echo e(url('/clientes')); ?>/<?php echo e($cliente->id); ?>">
              <div class="row list-contacts">
                <div class="col-md-3 text-center">
                  <?php echo e($cliente->id); ?>

                </div>
                <div class="col-md-3">
                  <?php echo e($cliente->razao_social); ?>

                </div>
                <div class="col-md-6">
                  <?php echo e($cliente->endereco); ?>, <?php echo e($cliente->numero); ?> - <?php echo e($cliente->bairro); ?> <?php echo e($cliente->cidade); ?> - <?php echo e($cliente->uf); ?>

                </div>
              </div>
            </a>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>