<?php $__env->startSection('content'); ?>
  <div class="row">
    <div class="col-md-11">
        <div class="form-group">
        <div class="panel panel-default">
          <div class="panel-heading"><i class="fa fa-list fa-1x"></i> Editar atendimento de <span class="label label-primary"><?php echo e($atendimento->contatos->nome); ?></span></div>
          <form method="POST" action="<?php echo e(url('/atendimentos')); ?>/<?php echo e($atendimento->id); ?>">
            <?php echo e(csrf_field()); ?>

            <div class="panel-body">
              <div class="row text-right">
                <div class="col-sm-offset-2 col-sm-10">
                  <a href="<?php echo e(url()->previous()); ?>" class="btn btn-warning"><i class="fa fa-arrow-left"></i> Voltar</a>
                  <button type="submit" class="btn btn-success">Salvar</button>
                </div>
              </div>
              <div class="row">
                <div class="col-md-4">
                  <div class="form-group">
                    <label for="text">Assunto </label>
                    <input type="text" class="form-control" value="<?php echo e($atendimento->assunto); ?>" name="assunto" id="assunto" placeholder="Assunto">
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="form-group">
                    <label for="text">Contato </label>
                    <input type="text" class="form-control" value="<?php echo e($atendimento->contatos->nome); ?>" name="contato-off" id="contato" placeholder="Contato" disabled>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="form-group">
                    <label for="text">Data criado </label>
                    <input type="text" class="form-control" value="<?php echo e($atendimento->created_at); ?>" name="data" id="data" placeholder="Criação" disabled>
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-md-12">
                  <div class="form-group">
                    <label for="text">Descrição </label>
                    <textarea class="form-control" width="100%" id="texto" rows="5" name="texto"><?php echo e($atendimento->texto); ?></textarea>
                  </div>
                </div>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>