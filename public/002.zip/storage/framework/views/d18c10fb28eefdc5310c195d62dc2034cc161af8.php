<?php
use Carbon\Carbon;
?>

<?php $__env->startSection('content'); ?>
  <div class="row">
    <div class="col-md-12">
      <div class="panel panel-default">
        <div class="panel-heading ">
          <i class="fa fa-list fa-1x"></i> Novo atendimento
        </div>
        <div class="panel-body">
          <div class="row pull-center">
            <div class="col-md-12">
              <form method="POST" action="<?php echo e(url('/atendimentos')); ?>/novo/busca">
                <div class="form-group form-inline text-center">
                  <?php echo e(csrf_field()); ?>

                  <input type="text" class="form-control" name="busca" id="busca" placeholder="Busca" size="10">
                  <button type="submit" class="btn btn-success" id="buscar" >Buscar</button>
                </div>
              </form>
            </div>
          </div>
          <div class="row">
            <div class="col-md-8 h3">
              <?php $__currentLoopData = $contatos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $contato): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                <div class="row list-contacts">
                  <div class="col-md-4 text-right">
                    <a class="btn btn-info" onclick="
                                                      $('#form').show();
                                                      $('#contato').val('<?php echo e($contato->nome); ?>');
                                                      $('#contatos_id').val('<?php echo e($contato->id); ?>');
                    ">
                      <i class="fa fa-gear"></i>
                    </a>
                  </div>
                  <div class="col-md-8">
                    <?php echo e($contato->nome); ?>

                  </div>
                </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            </div>
            <div class="col-md-4" style="display: none;" id="form">
              <form method="POST" action="<?php echo e(url('/atendimentos')); ?>/novo">
                <?php echo e(csrf_field()); ?>

                <div class="form-group">
                  <label>Atendimento para</label>
                  <input type="text" class="form-control" name="contato" id="contato" value="" disabled>
                  <input type="hidden" class="form-control" name="contatos_id" id="contatos_id" value="">
                </div>
                <div class="form-group">
                  <label>Assunto</label>
                  <input type="text" class="form-control" name="assunto" id="assunto" placeholder="Assunto">
                </div>
                <div class="form-group">
                  <label>Data</label>
                  <input type="text" class="form-control" name="data" id="data" value="<?php echo e(Carbon::now()); ?>">
                </div>
                <div class="form-group">
                  <label for="text">Descrição </label>
                  <textarea class="form-control" id="texto" rows="5" name="texto"></textarea>
                </div>
                <button type="submit" class="btn btn-success" id="enviar" >Enviar</button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>