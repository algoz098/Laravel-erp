<?php $__env->startSection('content'); ?>
  <div class="row">
    <div class="col-md-11">

        <div class="form-group">
        <div class="panel panel-default">
          <div class="panel-heading"><i class="fa fa-users fa-1x"></i> Novo relacionamento de <span class="label label-primary"><?php echo e($contato->nome); ?></span></div>
          <div class="panel-body">
            <div class="row text-right">
              <div class="col-sm-offset-2 col-sm-10">
                <a href="<?php echo e(url()->previous()); ?>" class="btn btn-warning"><i class="fa fa-arrow-left"></i> Voltar</a>
              </div>
            </div>
            <div class="row form-inline">
              <div class="col-md-4">
                <div class="form-group">
                  <label for="text">Relacionar <span class="label label-primary"><?php echo e($contato->nome); ?></span> com:</label>
                  <div class="row">
                    <div class="col-md-12  ">
                      <form method="POST" action="<?php echo e(url('/contatos')); ?>/2/relacoes/novo/busca">
                        <div class="form-group form-inline text-center">
                          <?php echo e(csrf_field()); ?>

                          <input type="text" class="form-control" name="busca" id="busca" placeholder="Busca" size="10">
                          <button type="submit" class="btn btn-success" id="buscar">Buscar</button>
                        </div>
                      </form>
                    </div>
                  </div>
                  <?php $__currentLoopData = $contatos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $contato_to): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <?php if($contato_to->id==$contato->id): ?>
                    <?php else: ?>
                      <div class="row list-contacts text-center">
                        <input type="radio" name="to_id" value="<?php echo e($contato_to->id); ?>" onclick="$('#to').text('<?php echo e($contato_to->nome); ?>'); $('#to2').text('<?php echo e($contato_to->nome); ?>'); $('#form').show(); $('#to_id').val('<?php echo e($contato_to->id); ?>');" > <?php echo e($contato_to->nome); ?>

                      </div>
                    <?php endif; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                </div>
              </div>
              <div class="col-md-8" style="display:none;" id="form">
                <form method="POST" action="<?php echo e(url('/contatos')); ?>/<?php echo e($contato->id); ?>/relacoes/novo">

                  <?php echo e(csrf_field()); ?>

                <div class="row">
                  <div class="form-group">
                    <label for="text"><span class="label label-primary"><?php echo e($contato->nome); ?></span> é </label>
                    <input type="text" class="form-control" value="" name="from_text" id="from_text" placeholder="Texto de relacionamento">
                    de <span id="to" class="label label-success"></span>
                  </div>
                </div>
                <div class="row">
                  <div class="form-group">
                    <label for="text"><span id="to2" class="label label-success"></span> é </label>
                    <input type="text" class="form-control" value="" name="to_text" id="to_text" placeholder="Texto de relacionamento">
                    de <span class="label label-primary"><?php echo e($contato->nome); ?></span>
                  </div>
                </div>
                <input type="hidden" class="form-control" value="" name="to_id" id="to_id">
                <button type="submit" class="btn btn-success">Salvar</button>
              </form>
            </div>
          </div>
        </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>