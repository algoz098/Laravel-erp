<?php $__env->startSection('content'); ?>
  <div class="row">
    <div class="col-md-11">
      <form method="POST" action="<?php echo e(url('/contatos')); ?>/<?php echo e($telefone->contatos_id); ?>/telefones/<?php echo e($telefone->id); ?>">
        <div class="form-group">
        <?php echo e(csrf_field()); ?>

        <input type="hidden" name="id" value="">
        <div class="panel panel-default">
          <div class="panel-heading"><i class="fa fa-users fa-1x"></i> Editar telefone de <?php echo e($telefone->contatos->nome); ?></div>
          <div class="panel-body">
            <div class="row text-right">
              <div class="col-sm-offset-2 col-sm-10">
                <button type="submit" class="btn btn-success">Salvar</button>
              </div>
            </div>
            <div class="row">
              <div class="col-md-3">
                <div class="form-group">
                  <label for="text">Tipo</label>
                  <input type="text" class="form-control" value="<?php echo e($telefone->tipo); ?>" name="tipo" id="tipo" placeholder="">
                </div>
              </div>
              <div class="col-md-9">
                <div class="form-group">
                  <label for="text">Numero</label>
                  <input type="text" class="form-control" value="<?php echo e($telefone->numero); ?>" name="numero" id="numero" placeholder="">
                </div>
              </div>
            </div>
        </div>
      </form>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>