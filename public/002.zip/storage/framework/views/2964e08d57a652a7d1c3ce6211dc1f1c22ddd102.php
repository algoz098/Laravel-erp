<!DOCTYPE html>
<html lang="pt">
  <head>
    <title>ERP - <?php echo $__env->yieldContent('title'); ?></title>

    <?php echo $__env->make('includes.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  </head>
  <body>
    <?php if(!Auth::guest()): ?>
    <div class="nav-side-menu">
      <?php echo $__env->make('partials.sidemenu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>

    <div class="right-bar">
      <?php echo $__env->make('partials.topbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <?php echo $__env->yieldContent('content'); ?>
    </div>
    <?php else: ?>
      <?php echo $__env->yieldContent('content'); ?>
    <?php endif; ?>
  </body>
</html>
