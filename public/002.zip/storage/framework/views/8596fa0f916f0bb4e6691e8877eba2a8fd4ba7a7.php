<?php $__env->startSection('content'); ?>
  <div class="row">
    <div class="col-md-12">
      <div class="panel panel-default">
        <div class="panel-heading"><i class="fa fa-users fa-1x"></i> Relacionamentos de <span class="label label-primary"><?php echo e($contato->nome); ?></span></div>
        <div class="panel-body">
          <div class="row text-right">
            <a href="<?php echo e(url()->previous()); ?>" class="btn btn-warning"><i class="fa fa-arrow-left"></i> Voltar</a>
            <a href="<?php echo e(url('/contatos')); ?>/<?php echo e($contato->id); ?>/relacoes/novo" class="btn btn-success">
              <i class="fa fa-plus"></i>
            </a>
          </div>
            <div class="row">
              <div class="col-md-6">
                <?php $__currentLoopData = $contato->from; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $from): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                  <div class="row h3 list-contacts">
                    <div class="col-md-3 text-right">
                      <a href="<?php echo e(url('/contatos')); ?>/<?php echo e($contato->id); ?>/relacoes/<?php echo e($contato->from[$key]->pivot->id); ?>/delete" class="btn btn-danger">
                        <i class="fa fa-ban"></i>
                      </a>
                      <a class="btn btn-primary" onclick="
                                                          $('#form').show();
                                                          $('#to').text('<?php echo e($from->nome); ?>');
                                                          $('#to2').text('<?php echo e($from->nome); ?>');
                                                          $('#to3').text('<?php echo e($from->nome); ?>');
                                                          $('#from_text').val('<?php echo e($contato->from[$key]->pivot->from_text); ?>');
                                                          $('#to_text').val('<?php echo e($contato->from[$key]->pivot->to_text); ?>');
                                                          $('#to_id').val('<?php echo e($contato->from[$key]->pivot->to_id); ?>');
                                                          ">
                        <i class="fa fa-pencil"></i>
                      </a>
                    </div>
                    <div class="col-md-7">
                      <?php echo e($contato->nome); ?> é
                      <span class="label label-success"><?php echo e($contato->from[$key]->pivot->from_text); ?></span>
                      de <?php echo e($contato->from[$key]->nome); ?>

                    </div>
                  </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                <?php $__currentLoopData = $contato->to; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $to): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                  <div class="row h3 list-contacts">
                    <div class="col-md-3  text-right">
                      <a href="<?php echo e(url('/contatos')); ?>/<?php echo e($contato->id); ?>/relacoes/<?php echo e($contato->to[$key]->pivot->id); ?>/delete" class="btn btn-danger">
                        <i class="fa fa-ban"></i>
                      </a>
                      <a class="btn btn-primary" onclick="
                                                          $('#form').show();
                                                          $('#to').text('<?php echo e($to->nome); ?>');
                                                          $('#to2').text('<?php echo e($to->nome); ?>');
                                                          $('#to3').text('<?php echo e($to->nome); ?>');
                                                          $('#from_text').val('<?php echo e($contato->to[$key]->pivot->to_text); ?>');
                                                          $('#to_text').val('<?php echo e($contato->to[$key]->pivot->from_text); ?>');
                                                          $('#to_id').val('<?php echo e($contato->to[$key]->pivot->from_id); ?>');
                                                          ">
                        <i class="fa fa-pencil"></i>
                      </a>
                    </div>
                    <div class="col-md-8">
                      <?php echo e($contato->nome); ?> é
                      <span class="label label-success"><?php echo e($contato->to[$key]->pivot->to_text); ?></span>
                      de <?php echo e($contato->to[$key]->nome); ?>

                    </div>
                  </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
              </div>
              <div class="col-md-6" id="form" style="display:none">
                <form id="form_relacao" method="POST" action="<?php echo e(url('/contatos')); ?>/<?php echo e($contato->id); ?>/relacoes/novo">
                  <div class="form-group">
                  <input type="hidden" class="form-control" value="" name="to_id" id="to_id" >
                  <?php echo e(csrf_field()); ?>

                  <div class="panel panel-default">
                    <div class="panel-heading">
                      <i class="fa fa-users fa-1x"></i> Editar relacionamento de
                      <span class="label label-primary"><?php echo e($contato->nome); ?></span> e
                      <span class="label label-success" id="to"></span>
                    </div>
                    <div class="panel-body">
                      <div class="row text-right">
                        <div class="col-sm-offset-2 col-sm-10">
                          <button type="submit" class="btn btn-success">Salvar</button>
                        </div>
                      </div>
                      <div class="row">
                        <div class="form-group form-inline">
                          <label for="text"><span class="label label-primary"><?php echo e($contato->nome); ?></span> é </label>
                          <input type="text" class="form-control" value="" name="from_text" id="from_text" >
                          de <span id="to2" class="label label-success"></span>
                        </div>
                      </div>
                      <div class="row">
                        <div class="form-group form-inline">
                          <label for="text"><span id="to3" class="label label-success"></span> é </label>
                          <input type="text" class="form-control" value="" name="to_text" id="to_text" placeholder="Texto de relacionamento">
                          de <span class="label label-primary"><?php echo e($contato->nome); ?></span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>