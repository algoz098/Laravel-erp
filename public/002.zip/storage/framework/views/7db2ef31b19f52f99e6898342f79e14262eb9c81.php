<?php $__env->startSection('content'); ?>
  <div class="panel panel-default">
    <div class="panel-heading"><i class="fa fa-users fa-1x"></i> Atualização do ERP</div>
      <div class="panel-body">
        <?php if($manifest["versao"] < $remoto["versao"]): ?>
          <div class="row" >
            <div class="col-md-3 pull-right text-right">
              <button class="btn btn-warning">
                <i class="fa fa-gear"></i> Atualizar ERP
              </button>
            </div>
          </div>
        <?php endif; ?>
        <div class="row">
          <div class="col-md-3">
            <h3>Atual:</h3>
            Laravel: <?php echo e(App::VERSION()); ?><br>
            WebGS Erp: <?php echo e($manifest["versao"]); ?><br>
            Data: <?php echo e($manifest["data"]); ?>

          </div>
          <div class="col-md-3">
            <h3>Remoto:</h3>
            Laravel: -<br>
            WebGS Erp: <?php echo e($remoto["versao"]); ?><br>
            Data: <?php echo e($remoto["data"]); ?>

          </div>
        </div>
      </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>