<?php $__env->startSection('content'); ?>
  <div class="panel panel-default">
    <div class="panel-heading"><i class="fa fa-users fa-1x"></i> Editar usuario do <span class="label label-info"><?php echo e($contato->nome); ?></span></div>
    <form method="POST" action="<?php echo e(url('/admin')); ?>/user/<?php echo e($contato->id); ?>">
      <?php echo e(csrf_field()); ?>

      <div class="panel-body">
        <div class="row pull-right">
          <a href="<?php echo e(url()->previous()); ?>" class="btn btn-warning"><i class="fa fa-arrow-left"></i> Voltar</a>
          <button class="btn btn-success" type="submit">Salvar</button>
        </div>
        <div class="row">
          <div class="col-md-6">
            <div class="dropdown">
              <div class="form-group">
                <label for="sel1">Usuario ativo?:</label>
                <select class="form-control" name="ativo" id="ativo">
                  <option value="1">Ativo</option>
                  <option value="0">Inativo</option>
                </select>
              </div>
              <ul class="dropdown-menu" aria-labelledby="dropdownMenu1">
                <li><a href="#">Action</a></li>
                <li><a href="#">Another action</a></li>
                <li><a href="#">Something else here</a></li>
                <li role="separator" class="divider"></li>
                <li><a href="#">Separated link</a></li>
              </ul>
            </div>
            <div class="form-group">
              <label for="text">E-Mail (login)</label>
              <input type="text" class="form-control" value="<?php echo e(isset($contato->email) ? $contato->email : ""); ?>" name="email" id="email" placeholder="Email">
              <?php if($errors->has('email')): ?>
                  <span class="help-block">
                      <strong><?php echo e($errors->first('email')); ?></strong>
                  </span>
              <?php endif; ?>
            </div>
            <div class="form-group">
              <label for="text">Senha</label>
              <input id="password" type="password" class="form-control" name="password" required>

                <?php if($errors->has('password')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('password')); ?></strong>
                    </span>
                <?php endif; ?>
              </div>
            </div>
          </div>
        </div>
      </div>
    </form>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>