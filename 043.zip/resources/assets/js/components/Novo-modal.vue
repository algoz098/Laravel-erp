<template>
  <button type="buton" class="btn btn-success" @click="$emit('novo-modal')">
    <icone icon="plus"></icone>
  </button>
</template>

<script>
export default {
}
</script>
