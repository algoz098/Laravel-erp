<template>
  <b-btn v-b-toggle="'busca-mais'"><icone icon="search-plus"></icone></b-btn>

</template>

<script>
    export default {
      
    }
</script>
