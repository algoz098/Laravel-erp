<template>
  <b-card header="Card header text"
          class="mb-2"
          title="Card title"
          sub-title="Card subtitle"
  >aaaaaa
  </b-card>
</template>

<script>
    export default {
        mounted() {
            console.log('Component mounted.')
        }
    }
</script>
