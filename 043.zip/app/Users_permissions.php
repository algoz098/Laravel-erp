<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Users_permissions extends Model
{
    protected $table = 'users_permissions';
}
